from django.contrib import admin
from .models import Brand, Model, Vehicle, Rent_contract, Customer

admin.site.register(Brand)
admin.site.register(Model)
admin.site.register(Vehicle)
admin.site.register(Customer)
admin.site.register(Rent_contract)


