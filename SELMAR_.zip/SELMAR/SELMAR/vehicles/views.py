from django.shortcuts import render, get_object_or_404
from .models import Brand, Model, Vehicle, Rent_contract, Rent_contractForm


def index(request):
    all_vehicles = Vehicle.objects.all()
    context = {'all_vehicles': all_vehicles}
    return render(request, 'vehicles/index.html', context)

def detail(request, brand_id):
    vehicle = get_object_or_404(Vehicle, pk=brand_id)
    return render(request, 'vehicles/detail.html', {'vehicle': vehicle})

def rent_contract_create_view(request, brand_id):
    vehicle = Vehicle.objects.get(pk=brand_id)
    form = Rent_contractForm(request.POST or None)
    if form.is_valid():
        form.save()
    context = {
        'form': form
    }
    return render(request, 'vehicles/rent_contract_create.html', context)

def rent_contract(request, brand_id):
    if request.method == 'POST':
        vehicle = Vehicle.objects.get(pk=brand_id)
        customer_first_name = request.POST.get('customer_first_name', '')
        customer_last_name = request.POST.get('customer_last_name', '')
        rent_contract_obj = Rent_contract(vehicle=vehicle, customer_first_name=customer_f_name, customer_last_name=customer_l_name)
        rent_contract_obj.save()
        return render(request, 'vehicles/rent_contract_create.html', {'form':form})




