from django.urls import path
from . import views

app_name = 'vehicles'

urlpatterns = [
    path('', views.index, name='index'),
    path('<int:brand_id>/', views.detail, name='detail'),
    path('<int:brand_id>/create_rent_contract', views.rent_contract_create_view, name='rent_contract_create_view'),

]
